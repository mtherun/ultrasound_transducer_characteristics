clc
clear all

myFolder = 'C:\Users\monis\Downloads\Ultrasound\Ultra\P2'; %pathname; % specify the path of the folder where the files subside

filePattern = fullfile(myFolder, '*.csv');
theFiles = dir(filePattern);
d=zeros(7,7);
width=[7.07 7.07 10 10 10];
figure(1)
tiledlayout(2,3)
tn=["Sample 2 with 500KHz Transducer","Sample 3 with 500KHz Transducer","Sample 6 with 500KHz Transducer","Sample 7 with 1MHz Transducer","Sample 7 with 500KHz Transducer"];
for k = 1 : length(theFiles)
    baseFileName = theFiles(k).name;
    fullFileName = fullfile(theFiles(k).folder, baseFileName);
    x=load(fullFileName);



    div=length(x)/10;
    time=0:1:length(x)-1;
    time=time*width(k)/div;

%     subplot(2,4,k)
    nexttile
    plot(time,(100*(x-max(x)/2)/(max(x)/2)))
    xlabel("Time in us")
    ylabel("Amplitude in %")
    title(sprintf("%s"),tn(k));

end

fl=length(theFiles);
%% Activity 1
%sample 2
t11=2.12825*10^-5;
t12=4.04143*10^-5;
l=60*10^-3;
v1=2*l/(t12-t11);
fprintf("The velocity of sample 2 is %.2f m/s \n \n", v1);

%sample 2
fprintf("The echoes were not registered properly in the sample 3\n \n");

%% Activity2
x=load("Activity_2_Sample_6.csv");
time=0:1:length(x)-1;
div=length(x)/10;
time=time*10/div;
figure(2);

plot(time,(100*(x-max(x)/2)/(max(x)/2)),[20.775 20.775],[-100 70.4],'--',[38.2875 38.2875],[-100 23.28],'--');
text(17,75,'Arrival time 1');
text(36,28,'Arrival time 2');
xlabel("Time in us")
ylabel("Amplitude in %")
title("Sample 6 with 500kHz Transducer")

l2=30*10^-3;
t31=2.0775*10^-5;
t32=3.82875*10^-5;
v2=2*l2/(t32-t31);
fprintf("The velocity of sample 6 is %.2f m/s \n ", v2);

rho=1.7;
z1=rho*v2;
fprintf("The acoustic impedance of sample 6 is %.2f Rayls \n ", z1);

zw=1000*1500;
zp=7800*3520;
zm=sqrt(zp*zw);
fprintf("The acoustic impedance of matching layer is %.2f Rayls \n", zm);
ft=10^6; %r theoretocal frequency
wavelength=v2/(4*ft);
fprintf("The thickness of the matching layer is %.2d m  \n", wavelength);
rd=100*(zm-z1)/zm;
fprintf("The relative difference of the matching layers is %.1f percent \n \n", rd);

%% Activity 3
x=load("Activity_3_500kHz.csv");
y=load("Activity_3_1MHz.csv");
t1=0:1:length(x)-1;
t2=0:1:length(y)-1;
div1=length(x)/10;
div2=length(y)/10;
t1=t1*10/div1;
t2=t2*10/div2;
figure(3)
plot(t1,(100*(x-max(x)/2)/(max(x)/2)),t2,(100*(y-max(y)/2)/(max(y)/2)))
xlabel("Time in us")
ylabel("Amplitude in %")
title("Sample 7 with 500kHz and 1MHz Transducer")
legend("500kHz transducer V189-RB - Sample 7 ", "1MHz Transducer V392 - Sample 7")
